import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { ServicesService } from '../../services.service';
import { StudentsService } from '../../_services/students.service';
import { AlertComponent } from '../../_alert/alert/alert.component';

@Component({
  selector: 'app-admission',
  templateUrl: './admission.component.html',
  styleUrls: ['./admission.component.css']
})
export class AdmissionComponent implements OnInit {

  classes = [];
  sections = [];
  alert_message: string;
  dialog_type: string;

  class: string;
  section: string;
  student;
  
  studentdetails: boolean = true;
  parentdetails: boolean = false;
  address: boolean = false;

  constructor(
    private fb: FormBuilder,
    private service: ServicesService,
    private studentservice: StudentsService, 
    public dialog: MatDialog,
    private dialogRef: MatDialogRef<AdmissionComponent>,
    @Inject(MAT_DIALOG_DATA) data) {
      
      this.class = data.class;
      this.section = data.section;
      this.student = data.student;
      this.dialog_type = data.dialog_type;
  }

  ngOnInit() {
    this.getClasses();
  }

  sudentadmissionForm: FormGroup = this.fb.group({
    admission_no: ['', Validators.required],
    first_name: ['', Validators.required],
    category: ['', Validators.required],
    blood_group: ['', Validators.required],
    roll_no: ['', Validators.required],
    last_name: ['', Validators.required],
    religion: ['', Validators.required],
    admission_date: ['', Validators.required],
    class_id: ['', Validators.required],
    gender: ['', Validators.required],
    phone: ['', Validators.required],
    bus_route_id: ['', Validators.required],
    section_id: ['', Validators.required],
    dob: ['', Validators.required],
    aadhar_no: ['', Validators.required],
    email: ['', Validators.required],
    //exceluploadfile: ['', Validators.required],
    father_name: ['', Validators.required],
    mother_name: ['', Validators.required],
    gaurdian_name: ['', Validators.required],
    gaurdian_relation: ['', Validators.required],
    father_contact: ['', Validators.required],
    mother_contact: ['', Validators.required],
    gaurdian_contact: ['', Validators.required],
    father_email: ['', Validators.required],
    mother_email: ['', Validators.required],
    gaurdian_email: ['', Validators.required],
    father_occupation: ['', Validators.required],
    mother_occupation: ['', Validators.required],
    gaurdian_occupation: ['', Validators.required],
    cur_address: ['', Validators.required],
    perm_address: ['', Validators.required],
    //parent_account_new: ['', Validators.required],
    //parent_account_create: ['', Validators.required],
    //docupload: ['', Validators.required]
  });

  get_studentForm(select) {
    if(select === 'studentdetails') {
      this.studentdetails = true;
      this.parentdetails = false;
      this.address = false;
    } else if(select === 'parentdetails') {
      this.studentdetails = false;
      this.parentdetails = true;
      this.address = false;
    } else if(select === 'address') {
      this.studentdetails = false;
      this.parentdetails = false;
      this.address = true;
    }
  }

  close() {
    this.dialogRef.close();
  }

  submitStudent() {
    this.sudentadmissionForm.value.student_id = this.student.student_id;
    this.dialogRef.close(this.sudentadmissionForm.value);
    if(this.dialog_type == 'add') {
      this.studentservice.addStudentadmission(this.sudentadmissionForm.value.section_id, this.sudentadmissionForm.value)
      .subscribe(
        res => { 
          if(res == true) {
            this.alert_message = "Student Added Successfully";
            this.openAlert(this.alert_message)
          } else {
            this.alert_message = "Student Not Added";
            this.openAlert(this.alert_message)
          }
        }
      )
    } else if(this.dialog_type == 'edit') {
      // this.service.editSubject(this.subjectForm.value, this.subject.subject_id)
      //   .subscribe(
      //     res => { 
      //       if(res == true) {
      //         this.alert_message = "Subject Edited Successfully";
      //         this.openAlert(this.alert_message)
      //       } else {
      //         this.alert_message = "Subject Not Edited";
      //         this.openAlert(this.alert_message)
      //       }
      //     }
      //   )
    }      
  }

  getClasses(){
    this.service.getClasses()
    .subscribe(
      res => { this.classes = res.school_classes, console.log(res) }
    )
  }

  sectionChange() {
    if(this.sudentadmissionForm.value.class_id == undefined || this.sudentadmissionForm.value.class_id == '') {
      this.alert_message = "Please Select Class";
      this.openAlert(this.alert_message)
    } else {
      this.service.getSections(this.sudentadmissionForm.value.class_id)
      .subscribe(
        res => { this.sections = res.class_sections, console.log(this.sections) }
      )
    }
    
  }

  openAlert(alert_message) {
    const alertConfig = new MatDialogConfig();

    alertConfig.autoFocus = true;
    alertConfig.width = '40%';

    alertConfig.data = {
      message: alert_message,
    };

    const alertRef = this.dialog.open(AlertComponent, alertConfig);

    alertRef.afterClosed().subscribe()
  }

}
