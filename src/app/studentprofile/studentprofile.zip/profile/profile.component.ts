import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { StudentsService } from '../../_services/students.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  constructor(private service: StudentsService, private route: ActivatedRoute) { }

  ngOnInit() {
  }

  edit_content = false;

  
  profilePannel: boolean = true;
  pgPannel: boolean = false;
  addrPannel: boolean = false;

  student_id = this.route.snapshot.paramMap.get('id');
  section_id = this.route.snapshot.paramMap.get('sec_id');

  student_details = {};  
  getStudentDetails() {    
    this.service.getStudentDetails(this.student_id)      
    .subscribe(        
      res => { this.student_details = res.students[0], console.log(res) 
      }      
    )  
  }
  // student_id(student_id: any) {
  //   throw new Error("Method not implemented.");
  // }

  profile_info(pannel) {
    if(pannel == "profile") {
      this.profilePannel = true;
      this.pgPannel = false;
      this.addrPannel = false;
    } else if(pannel == "pgdetails") {
      this.pgPannel = true;
      this.profilePannel = false;
      this.addrPannel = false;
    }else {
      this.addrPannel = true;
      this.profilePannel = false;
      this.pgPannel = false;
    }
  }

}
