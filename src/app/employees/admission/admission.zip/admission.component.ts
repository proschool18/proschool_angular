import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { EmployeesService } from '../../_services/employees.service';
import { AlertComponent } from '../../_alert/alert/alert.component';

@Component({
  selector: 'app-admission',
  templateUrl: './admission.component.html',
  styleUrls: ['./admission.component.css']
})
export class AdmissionComponent implements OnInit {

  employee;
  alert_message: string;
  dialog_type: string;

  //employeedetails: boolean = true;
  singleemployeedetails: boolean = true;
  employeeaddress: boolean = false;

  constructor(
    private fb: FormBuilder,
    private service: EmployeesService,
    public dialog: MatDialog,
    private dialogRef: MatDialogRef<AdmissionComponent>,
    @Inject(MAT_DIALOG_DATA) data) {

    this.employee = data.employee;
    this.dialog_type = data.dialog_type;
  }

  ngOnInit() {
  }

  employeeadmissionForm: FormGroup = this.fb.group({
    title: ['', Validators.required],
    code: ['', Validators.required],
    dob: ['', Validators.required],
    blood_group: ['', Validators.required],
    first_name: ['', Validators.required],
    designation: ['', Validators.required],
    gender: ['', Validators.required],
    marital_status: ['', Validators.required],
    last_name: ['', Validators.required],
    //bus_route_id: ['', Validators.required],
    email: ['', Validators.required],
    experience: ['', Validators.required],
    basic_pay: ['', Validators.required],
    phone: ['', Validators.required],
    joined_on: ['', Validators.required],
    salary_band: ['', Validators.required],
    perm_address: ['', Validators.required],
    cur_address: ['', Validators.required],
    state: ['', Validators.required],
    aadhat_no: ['', Validators.required],
    qualification: ['', Validators.required],
    country: ['', Validators.required],
    poan_no: ['', Validators.required],
    job_category: ['', Validators.required],
    postal_code: ['', Validators.required],
    passport_no: ['', Validators.required],
    spoken_languages: ['', Validators.required],
    employeeImage: ['', Validators.required],
  });

  onFileSelect(event) {
    console.log(event.target.files[0]);
    const file = event.target.files[0];
    this.employeeadmissionForm.get('employeeImage').setValue(file);
    console.log(file);
  }

  close() {
    this.dialogRef.close();
  }

  get_employeeForm(select) {
    if(select === 'singleemployeedetails') {
      //this.employeedetails = false;
      this.singleemployeedetails = true;
      this.employeeaddress = false;
    } else if(select === 'employeeaddress') {
      //this.employeedetails = false;
      this.singleemployeedetails = false;
      this.employeeaddress = true;
    }
  }

  submitEmployee() {
    this.employeeadmissionForm.value.employee_id = this.employee.employee_id;
    this.dialogRef.close(this.employeeadmissionForm.value);
    if (this.dialog_type == 'add') {
      this.service.addEmployeeadmission(this.employeeadmissionForm.value)
      .subscribe(
        res => {
          if (res == true) {
            this.alert_message = "Employee Added Successfully";
            this.openAlert(this.alert_message)
          } else {
            this.alert_message = "Employee Not Added Successfully";
            this.openAlert(this.alert_message)
          }
        }
      )
    } else if (this.dialog_type == 'edit') {
      // this.service.editSubject(this.subjectForm.value, this.subject.subject_id)
      //   .subscribe(
      //     res => { 
      //       if(res == true) {
      //         this.alert_message = "Subject Edited Successfully";
      //         this.openAlert(this.alert_message)
      //       } else {
      //         this.alert_message = "Subject Not Edited";
      //         this.openAlert(this.alert_message)
      //       }
      //     }
      //   )
    }
  }

  openAlert(message) {
    const alertConfig = new MatDialogConfig();

    alertConfig.autoFocus = true;
    alertConfig.width = '40%';

    alertConfig.data = {
      message: message,
    };

    const alertRef = this.dialog.open(AlertComponent, alertConfig);

    alertRef.afterClosed().subscribe();
  }

}
