import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { AlertComponent } from '../../_alert/alert/alert.component';
import { ServicesService } from '../../services.service';
import { EditschoolprofileComponent } from '../editschoolprofile/editschoolprofile.component';
import { HttpClient, HttpEventType } from '@angular/common/http';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {


  // imguplForm: FormGroup = this.fb.group({
  //   file: ''
  // });

  fileData: File = null;
  previewUrl:any = null;
  fileUploadProgress: string = null;
  uploadedFilePath: string = null;

  schoolprofile = {
    academic_year: '',
    address: '',
    affiliation: '',
    alternate_email: '',
    alternate_phone: '',
    chairman: '',
    class_from: '',
    coordinator: '',
    description: '',
    email: '',
    est_on: '',
    extra_curricular_activites: '',
    facilities_available: '',
    founder: '',
    medium: '',
    name: '',
    phone: '',
    principal: '',
    school_id: '',
    timings: '',
    status: '',
    vice_principal: '',
    website: '',
  };

  constructor(private service : ServicesService, public dialog: MatDialog, private fb: FormBuilder, private http: HttpClient) { }

  ngOnInit() { 
    this.getSchools();
    console.log(this.schoolprofile)
   }

  getSchools() {
    this.service.getSchools()
      .subscribe(
        res => { this.schoolprofile = res.schools[0], console.log(res) }
      )
  }

  editSchool() {
    this.openDialog()
  }

  // profileProgress(fileInput: any){
  //   this.fileData = <File>fileInput.target.files[0];
  //   this.previewProfile();
  //   console.log(this.fileData);

  //   const formData = new FormData();
  //   formData.append('files', this.fileData);

  //   this.service.addSchoolImags(formData)
  //   .subscribe(
  //     res=>{
  //       console.log(res,"ss");
  //     }
  //   )
  // }

  // previewProfile(){
  //   var mimeType = this.fileData.type;
  //   if (mimeType.match(/image\/*/) == null) {
  //     return;
  //   }
  //   var reader = new FileReader();      
  //   reader.readAsDataURL(this.fileData); 
  //   reader.onload = (_event) => { 
  //   this.previewUrl = reader.result; 
  //   }
  // }

  // onSubmit() {
  //   const formData = new FormData();
  //   formData.append('files', this.fileData);

  //   this.service.addSchoolImags(formData)
  //   .subscribe(
  //     res=>{
  //       console.log(res,"ss");
  //     }
  //   )

  // }

  fileProgress(fileInput: any) {
    this.fileData = <File>fileInput.target.files[0];
    this.preview();
    console.log(this.fileData);

    this.onSubmit();

    // const formData = new FormData();
    // formData.append('files', this.fileData);

    // this.service.addSchoolImags(formData)
    // .subscribe(
    //   res=>{
    //     console.log(res,"ss");
    //   }
    // )
  }

  preview() {
    // Show preview 
    var mimeType = this.fileData.type;
    if (mimeType.match(/image\/*/) == null) {
      return;
    }
    var reader = new FileReader();      
    reader.readAsDataURL(this.fileData); 
    reader.onload = (_event) => { 
    this.previewUrl = reader.result; 
    }
  }
 
  onSubmit() {
    const formData = new FormData();
    formData.append('files', this.fileData);

    this.service.addSchoolImags(formData)
    .subscribe(
      res=>{
        console.log(res,"ss");
      }
    )

  }
  // isFile = false;
  // getData() {
  //   this.isFile = !this.isFile;
  // }

  // editSchoolImg(){
  //   alert("img")
  // }

  // uploadFile(event){
  //   if(event.target.files.length > 0){
  //     const file = event.target.file[0];
  //     console.log(file);
  //     this.imguplForm.get('image').setValue(file);
  //   }
  // }

  // addSchoolImg(){
  //   var formData = new FormData();
  //   formData.append('uploadurl', this.imguplForm.get('image').value);

  //   this.service.addSchoolImags(formData)
  //   .subscribe(
  //     res => {console.log(res, "added img");})
  // }

  openDialog(): void {

    const dialogConfig = new MatDialogConfig();

    dialogConfig.autoFocus = true;
    dialogConfig.width = '60%';

    dialogConfig.data = {
      schoolprofile: this.schoolprofile,
    };

    const dialogRef = this.dialog.open(EditschoolprofileComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(
      data => {
        this.schoolprofile = data,
        console.log("Dialog output:", data)
      }
    )
  }

  openAlert(alert_message) {
    const alertConfig = new MatDialogConfig();

    alertConfig.autoFocus = true;
    alertConfig.width = '40%';

    alertConfig.data = {
      message: alert_message,
    };

    const alertRef = this.dialog.open(AlertComponent, alertConfig);

    alertRef.afterClosed().subscribe()
  }
}
