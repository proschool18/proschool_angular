import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ServicesService } from '../../services.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { AlertComponent } from '../../_alert/alert/alert.component';
import { from } from 'rxjs';

@Component({
  selector: 'app-editschoolprofile',
  templateUrl: './editschoolprofile.component.html',
  styleUrls: ['./editschoolprofile.component.css']
})
export class EditschoolprofileComponent implements OnInit {

  school_id;
  dialog_type: string;
  alert_message: string;

  schoolprofile = {
    academic_year: '',
    address: '',
    affiliation: '',
    alternate_email: '',
    alternate_phone: '',
    chairman: '',
    class_from: '',
    coordinator: '',
    description: '',
    email: '',
    est_on: '',
    extra_curricular_activites: '',
    facilities_available: '',
    founder: '',
    medium: '',
    name: '',
    phone: '',
    principal: '',
    school_id: '',
    timings: '',
    status: '',
    vice_principal: '',
    website: '',
  };

  schoolprofileForm: FormGroup = this.fb.group({
    academic_year: '',
    address: '',
    affiliation: '',
    alternate_email: '',
    alternate_phone: '',
    chairman: '',
    class_from: '',
    coordinator: '',
    description: '',
    email: '',
    est_on: '',
    extra_curricular_activites: '',
    facilities_available: '',
    founder: '',
    medium: '',
    name: '',
    phone: '',
    principal: '',
    school_id: '',
    timings: '',
    status: '',
    vice_principal: '',
    website: '',
  });

  constructor(
    private service : ServicesService,
    private fb: FormBuilder,
    public dialog: MatDialog,
    private dialogRef: MatDialogRef<EditschoolprofileComponent>,
    @Inject(MAT_DIALOG_DATA) data
  ) {
    //this.schoolprofile = data.school;
    this.schoolprofile = data.schools;
    this.dialog_type = data.dialog_type;
   }

  ngOnInit() {
    //console.log(this.schoolprofile);
    //this.schoolprofileForm.value.chairman = this.schoolprofile.chairman;
    //this.schoolprofileForm.value.founder = this.schoolprofile.founder;
  }
  
  editSchoolP() { 
    alert("ss");
    this.schoolprofileForm.value.school_id = this.schoolprofile.school_id;
    this.schoolprofileForm.value.chairman = this.schoolprofile.chairman;
    this.schoolprofileForm.value.founder = this.schoolprofile.founder;
    //this.school_id = this.schoolprofile.school_id;
    this.dialogRef.close(this.schoolprofileForm.value);
    this.service.editSchoolProfile(this.schoolprofileForm.value, this.school_id)
    .subscribe(
      res => { 
        if(res == true) {
          this.alert_message = "Class Edited Successfully";
          this.openAlert(this.alert_message)
        } else {
          this.alert_message = "Class Not Edited";
          this.openAlert(this.alert_message)
        }
      }
    )
  }

  openAlert(alert_message) {
    const alertConfig = new MatDialogConfig();

    alertConfig.autoFocus = true;
    alertConfig.width = '40%';

    alertConfig.data = {
      message: alert_message,
    };

    const alertRef = this.dialog.open(AlertComponent, alertConfig);

    alertRef.afterClosed().subscribe()
  }

  close_class() {
    this.dialogRef.close();
  }

}
