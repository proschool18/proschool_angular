import { Component, OnInit } from '@angular/core';
import { ServicesService } from '../../services.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-employeeattendance',
  templateUrl: './employeeattendance.component.html',
  styleUrls: ['./employeeattendance.component.css']
})
export class EmployeeattendanceComponent implements OnInit {

  constructor(private service: ServicesService, private fb: FormBuilder) { }

  ngOnInit() {
    this.getEmployees();
  }

  attendance = [];
  employees = [];
  all_employees = [];
  dateValue:boolean = false;
  current_date;
  current_month;
  current_year;
  i;

  employeeForm: FormGroup = this.fb.group({
    employee_type: ['', Validators.required],
    date: [''],
  });

  att_date(i) {
    if(i == 1) {
      this.dateValue = true;
    } else {
      this.dateValue = false;
      var d = new Date();
      var month = d.getMonth() + 1;
      var day = d.getDate()
      var year = d.getFullYear();
      var date = year + '-' + month + '-' + day;
      this.employeeForm.value.date = date;
    }
  }

  getEmployees() {
    this.service.getEmployees()
      .subscribe(
        res => { this.all_employees = res.employee, console.log(this.employees) }
      )
  }

  get_selectedemployees() {   
    if(this.employeeForm.value.employee_type === "teaching") {
      this.employees = this.all_employees.filter(emp => emp.job_category === "teaching");
    } else if(this.employeeForm.value.employee_type === "non-teaching") {
      this.employees = this.all_employees.filter(emp => emp.job_category === "non-teaching");
    } else if(this.employeeForm.value.employee_type === "administrative") {
      this.employees = this.all_employees.filter(emp => emp.job_category === "administrative");
    } else {
      this.employees = this.all_employees;
    }
  }

  submit(i, status) {
    this.employees[i].status = status;
  }

  allAttendance(status) {
    console.log(status)
    if(this.employees.length > 0) {
      for(this.i = 0; this.i < this.employees.length; this.i++) {
        this.employees[this.i].status = status;
      }
    } else {
      alert('No Employees selected')
    }
  }

  addEmployeeAttendance() { 
    if(this.employeeForm.value.employee_type == undefined){
      alert('Please Select the Employee Category')
    } else if(this.employees[0].status == 1) {
      alert('Please Select Attendance Status')
    } else if(this.dateValue == false) {
      this.current_date = new Date().getDate();
      if (this.current_date <= 9) {
        this.current_date = '0' + this.current_date;
      }
      console.log(this.current_date)
      this.current_month = new Date().getMonth() + 1;
      this.current_year = new Date().getFullYear();
      this.employeeForm.value.date = this.current_year + '-' + this.current_month + '-' + this.current_date;
      this.service.addEmployeeAttendance(this.employees, this.employeeForm.value.date)
      .subscribe(
        res => { console.log(res), alert("Attendance Submitted") }
      )
    } else {
      this.service.addEmployeeAttendance(this.employees, this.employeeForm.value.date)
      .subscribe(
        res => { console.log(res), alert("Attendance Submitted") }
      )
    }
  }

}
