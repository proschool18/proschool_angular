import { Component, OnInit } from '@angular/core';
import { ServicesService } from '../../services.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { AlertComponent } from '../../_alert/alert/alert.component';
import { AddfeeComponent } from '../addfee/addfee.component';
import { User } from '../../_models/user';

@Component({
  selector: 'app-collectfee',
  templateUrl: './collectfee.component.html',
  styleUrls: ['./collectfee.component.css']
})
export class CollectfeeComponent implements OnInit {

  constructor(private service: ServicesService, private fb: FormBuilder, public dialog: MatDialog) {}

  pageNo: number = 1;
  page_start: number = 0;
  page_counter = Array;
  pages: number = 10;

  collect:boolean;        
  user: User;
  showStudentList: boolean = false;

  selected_class:string;
  selected_section:string;
  selected_student: any = {student_id: '', first_name: '', last_name: ''};
  dialog_type: string;
  alert_message: string;

  ngOnInit() {
    this.user = JSON.parse(localStorage.getItem('currentUser'));
    this.getFeeTerms();
    this.getFeeTypes();
    if(this.user.role === 'admin') {
      this.collect = true;
    } else if(this.user.role === 'teacher' || this.user.role === 'parent') {
      this.collect = false;
    }
    if(this.user.role === 'parent') {
      this.selected_student.student_id = this.user.users[0].student_id;
      this.getCollectedFee();
    }
  }

  pageChange(x) {
    this.pageNo = x;
    this.page_start = (x - 1) * 10;
  } 

  students = [];
  collected_fee = [];
  studentFee:any = {};
  fee_terms = [];
  fee_types = [];
  student_fee = [
    {
      totalFee: '',
      totalStudentFee: '',
      totalBalanceFee: '',
    }
  ];

  collectfeeForm: FormGroup = this.fb.group({
    class_id: ['', Validators.required],
    fee_term_id: ['', Validators.required],
    fee_types_id: ['', Validators.required],
    total_fee: ['', Validators.required],
    fee_paid: ['', Validators.required],
    payment_mode: ['', Validators.required],
    discount: ['', Validators.required],
    fine: ['', Validators.required],
    phone: ['', Validators.required],
  });

  receiveClass($event) {
    this.selected_class = $event;
    this.collectfeeForm.value.class_id = this.selected_class;
    console.log(this.selected_class)
  }

  receiveSection($event) {
    this.selected_section = $event
    console.log(this.selected_section)
    this.getStudents();
  }

  getStudents() {
    if(this.selected_section == undefined || this.selected_section == '') {
      this.alert_message = "Please Select Class and Section";
      this.openAlert(this.alert_message)
    } else {
      this.service.getStudents(this.selected_section)
      .subscribe(
        res => { 
          this.students = res.students, 
          this.selected_student = this.students[0],
          this.getCollectedFee(),
          console.log(res) }
      )
    }
  }

  getCollectedFee() {
    if(this.selected_student.student_id == undefined || this.selected_student.student_id == '') {
      this.alert_message = "Please Select Student";
      this.openAlert(this.alert_message)
    } else {
      this.service.getCollectedFee(this.selected_student.student_id)
      .subscribe(
        res => { this.collected_fee = res.student_fee_details, 
          this.pages = Math.ceil(this.collected_fee.length / 10);
          console.log(this.collected_fee) 
        }
      )
    }
  }

  getFeeTerms() {
    this.service.getFeeTerms()
      .subscribe(
        res => { this.fee_terms = res.fee_term, console.log(res) }
      )
  }

  getFeeTypes() {
    this.service.getFeeTypes()
      .subscribe(
        res => { this.fee_types = res.fee_type, console.log(res) }
      )
  }

  addCollectedFee() {
    if (this.selected_student.student_id == undefined || this.selected_student.student_id == '') {
      this.alert_message = "Please Select Class, Section and Student";
      this.openAlert(this.alert_message)
    } else { 
      this.dialog_type = 'add';
      this.studentFee = {}
      this.openDialog(this.studentFee, this.dialog_type)
    }
  }

  deleteCollectedFee() {
    
  }

  openDialog(studentFee, dialog_type): void {

    const dialogConfig = new MatDialogConfig();

    dialogConfig.autoFocus = true;
    dialogConfig.width = '50%';

    dialogConfig.data = {
      class: this.selected_class,
      section: this.selected_section,
      student: this.selected_student,
      student_fee: studentFee,
      dialog_type: dialog_type,
    };

    const dialogRef = this.dialog.open(AddfeeComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(
      data => {
        console.log("Dialog output:", data)
        this.getCollectedFee();
      }
    );

  }

  openAlert(alert_message) {
    const alertConfig = new MatDialogConfig();

    alertConfig.autoFocus = true;
    alertConfig.width = '40%';

    alertConfig.data = {
      message: alert_message,
    };

    const alertRef = this.dialog.open(AlertComponent, alertConfig);

    alertRef.afterClosed().subscribe()
  }

}
